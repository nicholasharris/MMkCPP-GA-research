
#ifndef  __RANDOM_H__
#define  __RANDOM_H__

int Rnd(int low, int high);
int Flip(double prob);
void Randomize(double seed);
double FRandom(void);

#endif
