
typedef int ChromType;

typedef int Appstruct;
