
#ifndef __SELECT_H__

#define __SELECT_H__


int Proportional(int *sort, double sum, int size);
int Roulette(IPTR pop, int popsize, Population *p);
int RandomMate(IPTR pop, int popsize, Population *p);


#endif
